package com.egoebelbecker.teamcity;

public class TeamCity {

    public boolean getStatus() {
        return true;
    }

}
